# algo-derm

`algo-derm` is a TypeScript library that analyzes an INCI list and returns a dermatology-oriented product assessment.

It does **not** infer efficacy. It estimates **risk-oriented tolerance signals** across six axes:

- `irritation`
- `allergenicity`
- `comedogenicity`
- `dryness`
- `photosensitivity`
- `fungalAcne` (Pityrosporum folliculitis / Malassezia)

This README documents the **current implementation state in the codebase**, not the aspirational V2 design described in [docs/archive/ENGINE_V2_MATHEMATICS.md](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/archive/ENGINE_V2_MATHEMATICS.md).

## Documentation

For app integrations, start with the browser-friendly
[public API contract](docs/API_PUBLIC_CONTRACT.html). The Markdown source
([docs/API_PUBLIC_CONTRACT.md](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/API_PUBLIC_CONTRACT.md))
keeps the same contract in prose and typed snippets.

Active references on GitHub:

- [Documentation map](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/README.md)
- [External API readiness roadmap](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/API_EXTERNAL_READINESS_ROADMAP.md)
- [Algorithm overview](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/algorithm/README.html)
- [Runtime pipeline](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/algorithm/runtime-pipeline.html)
- [Scoring](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/algorithm/scoring.html)
- [Tags](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/algorithm/tags.html)
- [Calibration](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/algorithm/calibration.html)
- [Maintenance/debug](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/algorithm/maintenance-debug.html)
- [Regulatory data](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/REGULATORY_DATA.html)
- [Validation](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/VALIDATION.html)
- [Roadmap](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/ROADMAP.md)

Historical context:

- [Roadmap history](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/archive/ROADMAP_HISTORY.md)
- [Archive](https://github.com/MathieuSchaff/algo-derm/tree/main/docs/archive)

## What The Library Does Today

```
INCI string
  └─ parsing/*                 clean + split + normalize
       └─ resolution/ingredientResolution.ts    resolveIngredients: curated DB match + heuristic fallback + concentration
            └─ interactions.ts / regulatory.ts
            └─ productScoring.ts   per-axis risk · benefit · confidence
                 └─ productAssessment.ts   assessment envelope
                      └─ ProductAssessment   { overallRisk, rating, axes, benefits, ... }
                           └─ tags layer   optional ProductTag[] for simple claims
```

Given an INCI string or ingredient array, the library:

1. splits and normalizes ingredient names,
2. matches ingredients against an evidence database with alias support, botanical fallback, and a small common-name alias table,
3. estimates likely concentration importance from INCI position,
4. applies profile and context multipliers,
5. applies a small set of data-driven interaction rules,
6. falls back to pattern heuristics for some unmatched fragrance / allergen / essential-oil cases,
7. returns a structured product assessment with risk scores, confidence, contributors, coverage, regulatory notes, and limitations.

For app code, the normal flow is:

1. clean the INCI only if it came from a noisy scrape,
2. preserve the ordered ingredient list,
3. call `analyzeINCI(...)`,
4. return `summarizeAssessment(...)` from your API or UI layer.

For compact product claims such as `sans_parfum`, `peaux_sensibles`, or
`non-comedogene`, call `tagProduct(assessment, ingredients)` after
`analyzeINCI(...)`. Tags are derived from `ProductAssessment`; they are not
embedded in it unless you go through `summarizeAssessment(...)`.

There are **two public analysis paths**:

1. `analyzeINCI(...)`
   Main structured product assessment path. Use this when you need per-axis
   risks, benefits, drivers, tags, coverage, regulatory notes, and caveats.
2. `analyzeProbabilistic(...)`
   Alternative calibrated global-risk path. Use this only when you specifically
   need a single probability-like score and can consume `ProbabilisticAnalysis`
   directly.

These two paths now share some lower-level building blocks:

- `resolveIngredients(...)` for matching, heuristics, normalized INCI order, and concentration estimates,
- exposure multipliers and driver-axis extraction,
- interaction-rule evaluation over the shared resolution.

## Default Evidence Database

`analyzeINCI()` defaults to `MERGED_EVIDENCE_DB`, the curated dataset shipped
from `data/ingredients/ingredient_evidence.merged.json`. The current
operational snapshot is tracked in
[docs/STATUS.md](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/STATUS.md);
the merge report currently records 1066 entries. The smaller
`SAMPLE_EVIDENCE_DB` is available from `algo-derm/devtools` for demos and tests
and remains opt-in via the `evidenceDatabase` option.

Coverage and confidence are still bounded by what is curated. Ingredients absent from the dataset still lower confidence rather than hide risk.

## Installation

```bash
npm install algo-derm
```

## Which Function Should I Use?

| Use case | Call | Return |
| --- | --- | --- |
| Product card, product page, or backend API | `analyzeINCI(...)` then `summarizeAssessment(...)` | `AssessmentSummary` |
| Internal audit/debug screen | `analyzeINCI(...)` | `ProductAssessment` |
| Product claim badges | `tagProduct(assessment, ingredients)` | `ProductTag[]` |
| Ingredient warning badges | `ingredientTags(assessment)` | `IngredientTag[]` |
| Scraped retailer INCI | `cleanInciString(...)` or `cleanInci(...)` before analysis | repaired string or tokens |
| Canonical display/storage names | `canonicalizeINCI(labels)` | canonical INCI labels |
| Single calibrated global score | `analyzeProbabilistic(...)` | `ProbabilisticAnalysis` |

Most applications should expose `AssessmentSummary`, not the full engine
payload. `ProductAssessment` is intentionally richer and noisier: it is better
for audit screens, debugging, and partner integrations that need raw drivers.

## Quick Start

```ts
import { analyzeINCI, splitINCI, summarizeAssessment } from "algo-derm";

const rawInci =
  "Aqua, Alcohol Denat, Glycolic Acid, Citrus Limon Peel Oil, Parfum, Limonene";
const ingredients = splitINCI(rawInci);
const assessment = analyzeINCI(ingredients, {
  profile: { sensitiveSkin: true },
  context: { leaveOn: true, formulaType: "serum", estimatedPH: 3.5 },
});
const summary = summarizeAssessment(assessment, {
  rawIngredients: ingredients,
  includeIngredientTags: true,
});

console.log(summary.rating);
console.log(summary.overallRisk);
console.log(summary.confidence);
console.log(summary.coverage);
console.log(summary.topRiskDrivers);
console.log(summary.regulatoryNotes);
console.log(summary.limitationNotes);
```

## Overriding The Evidence Database

The package ships the merged dataset as the default. To use a custom or minimal database, pass `evidenceDatabase` explicitly:

```ts
import { analyzeINCI } from "algo-derm";
import { SAMPLE_EVIDENCE_DB } from "algo-derm/devtools";

const result = analyzeINCI("Aqua, Alcohol Denat, Parfum", {
  evidenceDatabase: SAMPLE_EVIDENCE_DB, // or your own Record<string, IngredientEvidence>
  context: { leaveOn: true, formulaType: "serum" },
});
```

## Public API

The package has three import surfaces:

- `algo-derm` — stable app-facing API for product analysis and compact summaries.
- `algo-derm/engine` — advanced scoring and resolution internals. These are intentionally exported, but formulas and helper semantics may change more often.
- `algo-derm/devtools` — offline fixtures, benchmark runners, calibration tools, and diagnostics. Do not use this as the runtime app contract.

Stable top-level value exports:

```ts
import {
  analyzeINCI,
  analyzeProbabilistic,
  summarizeAssessment,
  tagProduct,
  ingredientTags,
  cleanInci,
  cleanInciString,
  canonicalizeINCI,
  splitINCI,
  stripPreamble,
  normalize,
  buildKnownConcentrationsFromPackagingClaims,
  TAG_DEFS_VERSION,
} from "algo-derm";
```

Use `analyzeINCI(...)` for the full assessment and `summarizeAssessment(...)`
when returning a compact app/API payload. Use `tagProduct(...)` and
`ingredientTags(...)` for claim badges and ingredient-level warning badges.
`cleanInciString(...)` / `cleanInci(...)` repair scraper-damaged catalogue INCI
before splitting. `splitINCI(...)`, `stripPreamble(...)`, and `normalize(...)`
expose the same parsing behavior the analyzer uses internally.
`analyzeProbabilistic(...)` is a separate root API for consumers that want the
calibrated global-risk shape instead of the structured assessment shape.

Advanced engine exports:

```ts
import {
  aggregateProductRisk,
  analyzeINCIProbabilistic,
  evaluateInteractions,
  buildAliasIndex,
  estimateConcentrationPosterior,
  MERGED_EVIDENCE_DB,
  type ExposureMode,
  type InteractionEvaluationResult,
  type InteractionRule,
} from "algo-derm/engine";
```

Devtools exports for diagnostics, demos, and offline calibration:

```ts
import {
  calibrateThresholds,
  runValidationBenchmark,
  runBenchmarkBySubpopulation,
  SAMPLE_EVIDENCE_DB,
  SAMPLE_VALIDATION_CASES,
  type ConcentrationIntervalCalibrationResult,
  type PickCalibrationOptionsInput,
  type ValidationMetrics,
} from "algo-derm/devtools";
```

Most application code should call `analyzeINCI(...)` and return
`AssessmentSummary` from app APIs. The advanced exports expose engine internals
intentionally, but their formulas and helper semantics may change more often
than the stable analyzer wrapper.

Main stable top-level exported types include:

- `AnalyzeOptions`
- `AssessmentSummary`
- `AssessmentSummaryOptions`
- `IngredientEvidence`
- `ProductAssessment`
- `ProductContext`
- `ProbabilisticAnalysis`
- `UserProfile`
- `RiskAxis`
- `ProductAxisRisk`
- `ProductInteraction`
- `IngredientProbability`
- `MatchedEvidence`
- `HeuristicFlag`
- `ScoreExplanation`
- `ProductTag` — product-level tag returned by `tagProduct`
- `IngredientTag` — per-ingredient tag returned by `ingredientTags`
- `PackagingConcentrationClaim` — structured packaging concentration claim input

### `tagProduct(assessment, rawIngredients)`

Returns product-level tags from a pre-computed `ProductAssessment`. Tags answer
"does this product qualify as X?" with a tri-value state: `present`, `absent`,
or `insufficient_data`. Examples include `sans_parfum`, `hypoallergenique`,
and `peaux_sensibles`. The complete tag list and rule summaries live in
[docs/algorithm/tags.html](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/algorithm/tags.html).

```ts
import { analyzeINCI, tagProduct, splitINCI } from "algo-derm";

const inci = "Aqua, Parfum, Sodium Lauryl Sulfate, Glycerin";
const assessment = analyzeINCI(inci);
const tags = tagProduct(assessment, splitINCI(inci));
// [
//   { id: "sans_parfum", label: "Sans parfum", present: false, state: "absent", confidence: 0.82, ... },
//   { id: "peaux_sensibles", label: "Profil potentiellement doux", present: false, state: "absent", ... },
//   { id: "vegan", label: "Aucun ingrédient d'origine animale détecté", present: true, state: "present", ... },
//   { id: "grossesse_risque", label: "Signal à vérifier pendant la grossesse", present: false, state: "absent", ... },
//   ...
// ]
```

`ProductTag.state` is the tri-value truth (`present | absent | insufficient_data`);
`present` remains the back-compat boolean (`present === (state === "present")`).
Positive tolerance/safety tags are masked to `insufficient_data` when confidence
or coverage is too low, and active-claim tags are gated by product context
(for example rinse-off delivery or AHA/BHA pH).

### `ingredientTags(assessment)`

Returns per-ingredient signal tags — which specific ingredient triggered what concern. Useful for building product catalogs or filtering UIs without exposing raw scores.

```ts
import { analyzeINCI, ingredientTags } from "algo-derm";

const tags = ingredientTags(analyzeINCI("Aqua, Parfum, Retinol, Phenoxyethanol"));
// [
//   { ingredient: "Parfum",         tag: "fragrance" },
//   { ingredient: "Parfum",         tag: "eu_restricted" },
//   { ingredient: "Retinol",        tag: "eu_restricted", detail: "max 0.3%, leave-on only" },
//   { ingredient: "Phenoxyethanol", tag: "eu_restricted", detail: "max 1%" },
// ]
```

Possible `tag` values:
- Heuristic families: `fragrance`, `fragrance_allergen`, `essential_oil`, `paraben`, `sulfate_surfactant`, `formaldehyde_donor`, `isothiazolinone`, `denatured_alcohol`, `silicone`, `mineral_oil`, `soap`, `propylene_glycol`, `menthol`, `alkanolamide`
- Regulatory: `eu_restricted`, `eu_prohibited`, `ca_restricted`, `ca_prohibited`

### `summarizeAssessment(assessment, options)`

Returns a compact app-facing payload from the full `ProductAssessment`. Scores
are rounded, only the strongest drivers are retained, product tags are included
when raw ingredients or precomputed tags are provided, and ingredient tags can be
included on demand.

```ts
import { analyzeINCI, splitINCI, summarizeAssessment } from "algo-derm";

const rawInci = "Aqua, Glycerin, Niacinamide, Parfum";
const assessment = analyzeINCI(rawInci);
const summary = summarizeAssessment(assessment, {
  rawIngredients: splitINCI(rawInci),
  includeIngredientTags: true,
});
```

### Parsing Helpers

`cleanInciString(inci)` repairs real-world scraped INCI text before analysis:
broken separators (`|`, middle dots, bullets, en-dashes, underscore lists,
period-separated lists), leading labels, marketing prefixes, trailing legal
disclaimers, prose-before-header blurbs, and a small whitelist of glued chemical
tokens. It keeps display casing and names. `cleanInci(inci)` runs repair,
`splitINCI`, `normalize`, then `canonicalizeINCI` in one call and returns
`{ clean, ingredients, normalized, canonical }`.

`canonicalizeINCI(labels)` maps an already-split list to governed canonical INCI
names from the curated alias registry (`Vitamin B3` → `Niacinamide`, `BHA` →
`Salicylic Acid`); unknown labels pass through unchanged. It is display/storage
normalization — `analyzeINCI` resolves aliases internally, so it is not a
scoring prerequisite.

`stripPreamble(inci)` removes simple leading labels such as `Ingredients:`,
`Composition:`, or `INCI:`. `splitINCI(inci)` splits a well-formed INCI
declaration into ordered ingredient tokens, preserving decimal values such as
`0,5`. `normalize(value)` returns the canonical matching form used by the
evidence resolver.

```ts
import { cleanInci, cleanInciString, normalize } from "algo-derm";

const raw = "FORMULE INCI : AQUA | GLYCERIN | SALICYLICACID";
const clean = cleanInciString(raw);
const { ingredients, normalized } = cleanInci(raw);
const key = normalize("Rétinol");
```

`cleanInciString` is best-effort and safe to call on already clean lists, but it
does not enforce storage guardrails. If you write cleaned strings back to a
catalogue, compare token counts before committing. These helpers are still not a
full INCI grammar.

### Packaging Concentration Claims

`analyzeINCI(...)` accepts structured packaging claims through
`options.packagingClaims`. Claims are converted into `context.knownConcentrations`
before scoring. Explicit `context.knownConcentrations` entries take precedence.

```ts
import { analyzeINCI } from "algo-derm";

const assessment = analyzeINCI("Aqua, Niacinamide, Glycerin", {
  context: { leaveOn: true, formulaType: "serum" },
  packagingClaims: [
    { ingredientSlug: "niacinamide", concentrationPct: 5 },
  ],
});
```

Use `buildKnownConcentrationsFromPackagingClaims(...)` directly only when you
need the intermediate `Record<string, number>` for your own context assembly.

Advanced engine types such as `InteractionRule`,
`InteractionEvaluationResult`, and `ExposureMode` are exported from
`algo-derm/engine`. Devtools types such as `ValidationMetrics`,
`PickCalibrationOptionsInput`, and `ConcentrationIntervalCalibrationResult` are
exported from `algo-derm/devtools`.

## Input Model

### `analyzeINCI(inci, options)`

Accepted `inci` input:

- comma-separated string
- `string[]`

Accepted options:

```ts
type AnalyzeOptions = {
  evidenceDatabase?: Record<string, IngredientEvidence>;
  profile?: UserProfile;
  context?: ProductContext;
  packagingClaims?: readonly PackagingConcentrationClaim[];
};
```

### `ProductContext`

```ts
type ProductContext = {
  leaveOn: boolean;
  formulaType?:
    | "serum"
    | "cream"
    | "gel"
    | "cleanser"
    | "gentle_cleanser"
    | "lotion"
    | "sunscreen";
  estimatedPH?: number;
  knownConcentrations?: Record<string, number>;
};
```

### `UserProfile`

```ts
type UserProfile = {
  sensitiveSkin?: boolean;
  acneProne?: boolean;
  rosacea?: boolean;
  pregnant?: boolean;
};
```

## Output Model

The main path returns `ProductAssessment`.

```
ProductAssessment
 ├─ overallRisk: 0..1          global bounded risk score
 ├─ rating: low|medium|high    fixed thresholds (< 0.33 / < 0.66 / ≥ 0.66)
 ├─ confidence: 0..1           drops when many ingredients are unknown
 ├─ confidenceLabel            low | medium | high
 ├─ context: ProductContext    context passed to analyzeINCI (leaveOn, formulaType, …)
 │                              exposed so tagProduct MAPPED_TAGS can apply context-aware
 │                              rules without a separate context argument
 │
 ├─ productAxisRisk            one entry per risk axis
 │    └─ { axis, risk: 0..1, confidence, drivers[] }
 │         drivers[]: [{ ingredient, contribution, source }]
 │                    source = matchedEvidence | heuristicFlag | interaction
 │
 ├─ productBenefits            same shape — soothing, hydrating, barrierSupport, …
 │    └─ { axis, benefit: 0..1, confidence, drivers[] }
 │
 ├─ explanation
 │    ├─ topRiskAxis           axis with highest risk
 │    ├─ topDrivers[]          sorted by |contribution|, all sources mixed
 │    ├─ topBenefitAxis
 │    ├─ topBenefitDrivers[]
 │    ├─ confidenceFactors[]   reasons confidence was lowered
 │    └─ limitationNotes[]
 │
 ├─ coverage
 │    ├─ matched               ingredients found in evidence DB
 │    ├─ heuristicOnly         matched by pattern only (no evidence record)
 │    ├─ unmatched             unknown to both DB and heuristics
 │    ├─ total
 │    ├─ ratio                 matched / total
 │    └─ confidencePenalty     0..1 subtracted from confidence
 │
 ├─ contributors[]             per-ingredient probability from matched evidence
 ├─ interactions[]             fired interaction rules with their adjustment
 ├─ matchedEvidence[]          ingredients resolved to a curated evidence record
 ├─ heuristicFlags[]           pattern-detected ingredients (fragrance, paraben, …)
 ├─ unmatchedIngredients[]     ingredients with no match at all
 ├─ regulatoryNotes[]          prohibited / restricted notes from evidence records
 ├─ declarationOnlyRisk        informational tail-declaration caveat
 └─ ingredientResolution       non-enumerable resolved INCI seam for downstream consumers
```

### Top-Level Fields

| Field | Meaning |
|---|---|
| `overallRisk` | Global bounded risk score in `0..1` |
| `rating` | `low`, `medium`, or `high` using fixed thresholds |
| `productAxisRisk` | Per-axis risk, confidence, and drivers |
| `confidence` | Aggregate confidence in `0..1` |
| `confidenceLabel` | `low`, `medium`, `high` |
| `context` | `ProductContext` used during analysis (leaveOn, formulaType, …) — available to `tagProduct` MAPPED_TAGS for context-aware rules |
| `coverage` | How many ingredients were matched, heuristic-only, or unmatched |
| `explanation` | Top axis, top drivers, confidence factors, limitation notes |
| `contributors` | Ingredient-level matched contributors |
| `interactions` | Fired interaction rules |
| `matchedEvidence` | Ingredients matched to evidence |
| `unmatchedIngredients` | Ingredients with no evidence and no heuristic match |
| `heuristicFlags` | Pattern-based detections used when evidence is missing |
| `regulatoryNotes` | Prohibited / restricted notes from evidence records |
| `declarationOnlyRisk` | Informational caveat for tail-declaration risk; does not change `overallRisk` or `rating` |

### Risk Labels

Fixed rating thresholds:

- `low` if risk `< 0.33`
- `medium` if risk `< 0.66`
- `high` otherwise

Confidence label thresholds:

- `low` if confidence `< 0.45`
- `medium` if confidence `< 0.75`
- `high` otherwise

## How The Current Algorithm Works

This section describes the implementation in `src/`, not the future V2 design docs.
For deeper algorithm details and maintenance/debug guidance, use:

- [Algorithm overview](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/algorithm/README.html)
- [Runtime pipeline](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/algorithm/runtime-pipeline.html)
- [Scoring](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/algorithm/scoring.html)
- [Tags](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/algorithm/tags.html)
- [Calibration](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/algorithm/calibration.html)
- [Maintenance/debug](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/algorithm/maintenance-debug.html)

### 1. Parsing And Normalization

The parser is intentionally simple:

- `cleanInciString()` repairs scraper-damaged catalogue strings before split, including broken separators, marketing/prose/legal noise, and a small glued-token whitelist
- `cleanInci()` returns the repaired string, ordered ingredient tokens, normalized matching keys, and governed canonical INCI names
- `canonicalizeINCI()` maps a split ingredient list to governed canonical INCI names from the curated alias registry (unknown tokens pass through)
- `splitINCI()` splits well-formed comma lists and strips trailing sentence punctuation (`.`, `;`) per token
- `stripPreamble()` removes simple labels such as `Ingredients:` or `INCI:` when present
- `normalize()` lowercases, transliterates common French ingredient labels to Latin INCI terms, strips accents, removes most punctuation, compresses whitespace, and keeps basic alphanumerics plus hyphens

`analyzeINCI(...)` validates and splits raw strings, but it does not run the
scraper cleaner automatically. For retailer/catalogue data, run
`cleanInciString(raw)` or `cleanInci(raw)` first. This is enough for practical
alias matching but it is not a full INCI grammar.

### 2. Evidence Matching

The engine builds an alias index from:

- record key
- canonical `evidence.inci`
- optional `aliases`
- a small JSON table of common-name / marketing aliases when the canonical INCI exists in the loaded database

It also performs a small botanical normalization trick by stripping words like `leaf`, `flower`, and `peel` for some oil/extract matching.

If an ingredient cannot be matched to evidence:

1. heuristic rules are checked,
2. if no heuristic matches, the ingredient is treated as unmatched and lowers confidence.

### 3. Concentration Estimation

Concentration starts from a **per-ingredient Beta posterior estimate** based on:

1. INCI position prior,
2. formula-type prior tweaks,
3. leave-on vs rinse-off scaling,
4. and pseudo-evidence based on ingredient family or curated min/max concentration metadata.

Important current constants:

- first ingredient prior mean: about `70%`
- second ingredient prior mean: about `30%`
- early mid-list ingredients: around `15%`
- mid-list ingredients: around `7%`
- tail ingredients: around `2%`

Ingredient-family pseudo-evidence is currently coarse:

- `solvent`
- `active`
- `preservative`
- `uv_filter`
- `allergen`
- `default`

The classifier then applies a formula-level constrained solver (`solverMeanPct`)
to keep matched ingredients monotone-consistent with INCI order and feasible under
known concentration claims/caps. Scoring uses `effectiveConcentrationWeight(...)`:
solver mean when present, pre-solver `weight` as fallback.

The output of this stage includes:

- `meanPct`
- `solverMeanPct` when the formula-level solver ran
- `ciLowPct`
- `ciHighPct`
- `weight`

Important limitation:

These concentration estimates remain approximate. The solver constrains the
matched portion of the formula; unmatched ingredients and undisclosed formulation
details mean the engine still does **not** reconstruct the exact full composition.

### 4. Evidence Weighting

Each evidence record receives a confidence weight:

- `A = 1.00`
- `B = 0.85`
- `C = 0.65`
- `D = 0.45`

Study-count adjustments:

- `> 10` studies: `+0.05`
- `< 3` studies: `-0.10`
- floor: `0.30`

These weights are internal calibration constants. They are not presented in code as externally validated clinical coefficients.

### 5. Axis-Level Ingredient Signal

For each matched ingredient and each axis, the engine computes:

1. normalized axis risk from `evidence.risk[axis] / 5`,
2. concentration effect using `sqrt(concentration.weight)`,
3. exposure multiplier from leave-on / rinse-off context,
4. profile multiplier for the relevant user profile,
5. evidence weight.

In simplified form:

```text
axisSignal
  = axisRisk
  × sqrt(concentrationWeight)
  × exposureMultiplier
  × profileAxisMultiplier
  × evidenceWeight
```

Profile multipliers are axis-specific:

- `sensitiveSkin` boosts `irritation` and `dryness`
- `rosacea` boosts `irritation` and `photosensitivity`
- `acneProne` boosts `comedogenicity` and `fungalAcne`
- `pregnant` boosts `photosensitivity`

### 6. Interaction Rules

Interactions are currently **data-driven additive adjustments** from `data/rules/interaction_rules.json`.

Current shipped rule types include:

- alcohol + fragrance
- alcohol + fragrance allergen
- acid + alcohol
- multiple essential oils
- niacinamide + glycerin mitigation
- AHA low-pH rule when `estimatedPH < 4`
- BHA low-pH rule when `estimatedPH < 4`
- pregnancy/profile rules for retinoids, hydroquinone, and selected irritant/allergen contexts

Mitigation interactions can also appear in `explanation.topDrivers` with a negative signed contribution when they materially affect the explanation.

Important limitation:

These are discrete additive rules, not concentration-aware mechanistic simulations.

### 7. Heuristic Rules

When evidence is missing, the engine can still emit pattern-based heuristic flags for:

- fragrance
- fragrance allergen
- essential oil / botanical oil patterns
- furocoumarin-rich botanical patterns
- formaldehyde donors, isothiazolinones, parabens, sulfates, denatured alcohol, menthol, silicones, mineral oils, soap salts, and related families

Heuristic signals are scaled down relative to curated evidence and are kept separate in the explanation model.

### 8. Axis Aggregation

For each axis, the engine builds a driver set from:

- matched evidence contributors
- heuristic flags
- matched interactions

Axis score:

```text
axisRisk
  = 0.65 × max(driverContribution)
  + 0.35 × mean(driverContribution)
  + interactionAdjustment
```

Then the result is clamped to `0..1`.

This makes the algorithm **max-dominated**, not purely additive.

### 9. Overall Product Aggregation

Overall risk combines the axis scores and positive interactions:

```text
overallRisk
  = 0.60 × max(axisRisks)
  + 0.40 × mean(axisRisks)
```

Then the result is clamped to `0..1`.

Interactions are already folded into the relevant axis risks, so they are not
added a second time at the overall stage. A single dominant high-risk axis still
has substantial influence on the final product score.

### 10. Confidence Model

Confidence is influenced by:

1. average confidence of matched contributors,
2. matched coverage ratio,
3. heuristic-only ingredient ratio,
4. unmatched ingredient penalty.

In simplified form:

```text
confidence
  = averageContributorConfidence × matchedRatio
  + heuristicRatio × 0.20
  - unmatchedRatio × 0.25
```

Consequences:

- unmatched ingredients reduce confidence
- heuristic-only signals add some weak confidence but do not behave like real evidence
- low-coverage products can still produce risk scores, but those scores should be interpreted cautiously

## The Alternative Probabilistic Path

`analyzeProbabilistic(...)` is the root-package wrapper for the separate
probabilistic scoring path. The lower-level engine implementation is exported as
`analyzeINCIProbabilistic(...)` from `algo-derm/engine` for advanced/internal
use.

It:

1. computes a weighted multi-axis signal per ingredient,
2. applies a logistic transform,
3. averages ingredient probabilities,
4. adds interaction adjustment,
5. computes a simple confidence-dependent CI width.

This path returns `ProbabilisticAnalysis`, not `ProductAssessment`. It is useful
when an integration explicitly wants a single global risk probability and
confidence interval. It does not have a `summarizeAssessment(...)` equivalent,
so most app-facing payloads should still use `analyzeINCI(...)` plus
`summarizeAssessment(...)`.

## Current Dataset State

The active snapshot lives in
[docs/STATUS.md](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/STATUS.md)
so README numbers do not drift. The current merge report is
`data/ingredients/reports/merge_report.json` and records:

- dataset version: `0.3.0`;
- generated source date: `2026-04-25`;
- merged entries: `1066`;
- conflicts: `0`.

The published package ships `data/ingredients/ingredient_evidence.merged.json`,
and `analyzeINCI()` loads it as the default `evidenceDatabase`.
`SAMPLE_EVIDENCE_DB` is available from `algo-derm/devtools` for demos and tests.

## Validation And Tests

Current automated testing is **smoke-level**, not full clinical validation.

What is covered today:

- bounded output checks
- regulatory-note behavior
- benchmark metric shape and bounds
- calibration threshold ordering
- separation of matched evidence / heuristic flags / unmatched ingredients
- sample benchmark non-regression floor for `macroF1`
- Sephora weak-supervision low|medium guardrail and near-duplicate drift checks
- convergence between the structured and probabilistic paths for contributor drivers and public concentration estimates

What the sample benchmark actually is:

- `50` sample validation cases in `src/devtools/sampleValidationCases.ts`
- benchmarked through `runValidationBenchmark()`
- grouped by profile through `runBenchmarkBySubpopulation()`

This is useful for regression control, but it is **not** enough to claim broad clinical validation.

## What The Library Does Not Do

The current implementation does **not** do the following:

- run Monte Carlo or Latin hypercube sampling
- implement Dempster-Shafer evidence fusion
- model molecular weight penetration, Henderson-Hasselbalch chemistry, or flux integrals
- learn from user feedback
- infer emulsion structure, stability, preservation robustness, packaging effects, or raw material grade
- infer exact full-formula concentration from INCI order
- model full skincare-routine interactions across multiple products

Those ideas are discussed in docs such as [docs/archive/ENGINE_V2_MATHEMATICS.md](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/archive/ENGINE_V2_MATHEMATICS.md), but they are **not** the current production implementation.

## Repository Structure

```text
src/
  api/
    analyzer.ts               public analyzeINCI wrapper
    index.ts                  re-exports analyzeINCI + public types
  parsing/                    INCI cleaning, splitting, and normalization
  index.ts                    public exports (re-exports api/)
  engine/
    productAssessment.ts      product assessment orchestrator
    resolution/               alias matching, resolveIngredients seam, heuristics
    productScoring.ts         risk, benefit, coverage, confidence scoring
    productExplanation.ts     ScoreExplanation assembly
    tags/                     derived ProductTag and IngredientTag helpers
    regulatory.ts             curated + official-list regulatory notes
    axes.ts                   canonical risk/benefit axes
    probabilistic.ts          alternate probabilistic path
    sharedSignals.ts          shared exposure and driver-axis helpers
    concentration/            concentration priors, family classifier, pins, joint sampling, QP solver
    interactions.ts           rule matching and validation
    mergedEvidence.ts         loads the curated merged dataset as the default
    constants/                calibrated weights and thresholds (scoring, evidence, …)
    utils.ts                  evidence weighting, profile multipliers, labels
  devtools/                   benchmark/calibration/fixtures (algo-derm/devtools)
    validation.ts             confusion matrix and F1 metrics
    benchmark.ts              benchmark orchestration
    calibration.ts            rating-threshold search
    sephoraValidation.ts      Sephora/Kaggle corpus benchmark
    sampleEvidence.ts         small demo evidence database with concentration bounds
    sampleValidationCases.ts  tiny benchmark set
data/
  ingredients/
    ingredients.jsonl         ingredient evidence source (risk/benefit, regulatory, …)
    ingredient_evidence.merged.json
    evidence_manifest.json
    reports/
      merge_report.json
  inci/
    inci_aliases.jsonl          canonical INCI ↔ alias map (source of truth)
    inci_aliases.generated.json require()-able twin for the node-free runtime
  rules/
    fr_normalization.json     generic FR normalization maps
    heuristic_rules.json      pattern heuristics
    interaction_rules.json    additive interaction rules
  templates/                  reusable curation templates and examples
scripts/
  build-evidence-db.ts        ingredients/ingredients.jsonl (+ inci aliases) -> generated JSON
  validate-evidence-db.ts     schema validation on generated JSON
  merge-evidence-sources.ts   merge manifest sources → merged.json
  validate-manifest.ts        manifest integrity check
  analyze-inci.ts             interactive/single-shot INCI summary CLI
  tag-products.ts             batch-tag a product list (JSON/CSV) → ingredientTags per product
  (all scripts run via `node --import tsx scripts/<name>.ts`; no dist/ build required)
test/
  *.test.ts                   smoke tests run via tsx against src/
docs/
  README.md                         documentation map
  CODEBASE_MAP.md                   source layout and module responsibilities
  ROADMAP.md                        current roadmap (active view)
  REGULATORY_DATA.md                active regulatory maintenance reference
  VALIDATION.md                     active validation method (authoritative vs weak supervision)
  DATA_PIPELINE.md                  dataset workflow
  HOW_TO_CURATE_INGREDIENT.md       practical ingredient curation workflow
  CURATION_CHECKLIST.md             curation checklist
  algorithm/
    README.md                       algorithm docs index
    runtime-pipeline.md             analyzeINCI runtime flow
    scoring.md                      scoring paths + confidence/coverage/declarationOnlyRisk
    tags.md                         ProductTag and IngredientTag output layer
    calibration.md                  threshold/calibration notes
    maintenance-debug.md            maintenance/debug playbooks
  archive/ROADMAP_HISTORY.md        detailed roadmap/session history
  archive/ENGINE_V2_MATHEMATICS.md  aspirational future design (not current state)
  archive/                          historical prompts and scratch notes
```

## Development Commands

```bash
npm run build
npm run typecheck
npm run typecheck:test
npm run lint
npm run deadcode
npm run test:smoke
npm run test:package
npm run build:dataset
npm run validate:dataset
npm run report:dataset
npm run validate:manifest
npm run merge:dataset
npm run check:all
```

Command meanings:

- `build`: compile TypeScript to `dist/`
- `typecheck`: strict type check on `src/` without output
- `typecheck:test`: strict type check on `test/` (separate `tsconfig.test.json`)
- `lint` / `lint:fix`: Biome lint + formatter (use `:fix` to apply auto-fixes)
- `deadcode`: Knip report for unused files/exports
- `test:smoke`: run `test/*.test.ts` via tsx against `src/` (no build step)
- `test:package`: build, pack, install the tarball in a temp project, and verify CJS, ESM, TypeScript, default DB loading, package files, and package size budget
- `build:dataset`: `data/ingredients/ingredients.jsonl` (aliases joined from `data/inci/inci_aliases.jsonl`) to generated JSON
- `validate:dataset`: validate generated dataset structure
- `report:dataset`: print curation coverage stats
- `validate:manifest`: validate evidence manifest
- `merge:dataset`: merge manifest-listed evidence sources
- `check:all`: full local quality gate (mirrors CI)

## Guidance For Humans And LLMs

If you are trying to understand the current algorithm quickly, the right mental model is:

1. this is a **rule-and-weight engine**, not a learned model,
2. the main path is a **structured per-axis scorer** with confidence and explanation,
3. concentration is a **Bayesian-style positional approximation**, not a full compositional reconstruction,
4. unmatched ingredients mostly reduce confidence unless heuristic rules catch them,
5. interaction modeling is **small, explicit, and additive**,
6. the default bundled database is the curated merged dataset (`MERGED_EVIDENCE_DB`); `SAMPLE_EVIDENCE_DB` is opt-in.

If you need the future intended direction, read [docs/archive/ENGINE_V2_MATHEMATICS.md](https://github.com/MathieuSchaff/algo-derm/blob/main/docs/archive/ENGINE_V2_MATHEMATICS.md) separately and treat it as roadmap material, not as a description of the code that runs today.
