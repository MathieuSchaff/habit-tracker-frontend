# Public API Contract

This document is the recommended integration contract for applications using
`algo-derm`. It describes the package surface that app code should depend on,
the payload to return from an app API, and the caveats that must stay visible to
users.

## Import Surfaces

`algo-derm` is the stable app-facing surface. Use it for runtime product
analysis, probabilistic scoring, compact summaries, product tags, ingredient
tags, and parsing helpers.

`algo-derm/engine` is an advanced surface for diagnostics or controlled
internal integrations. It remains intentionally unstable before 1.0: formulas,
helper semantics, and exported internals may change more often than the root API.
Do not make it the default app contract.

`algo-derm/devtools` is for offline diagnostics, fixtures, benchmarks, and
calibration utilities. Do not ship it as the runtime app contract.

Pre-1.0 policy: root API breaking changes should be called out in the changelog
and shipped with an explicit version bump. `/engine` and `/devtools` can move
faster while they are documented as advanced or offline surfaces.

## Which Function Should I Call?

Use the root package unless you are building maintenance tooling.

| Need | Call | Return this |
| --- | --- | --- |
| Product card, product detail page, or backend response | `analyzeINCI(...)` then `summarizeAssessment(...)` | `AssessmentSummary` |
| Audit screen or advanced partner integration | `analyzeINCI(...)` | `ProductAssessment` |
| Product-level badges such as `sans-parfum` | `tagProduct(assessment, ingredients)` | `ProductTag[]` |
| Ingredient-level badges such as fragrance or EU restriction | `ingredientTags(assessment)` | `IngredientTag[]` |
| Noisy scraped retailer INCI | `cleanInciString(...)` or `cleanInci(...)` before analysis | repaired string or ordered tokens |
| Canonical names for display/storage | `canonicalizeINCI(labels)` | canonical INCI labels |
| Single calibrated global-risk score | `analyzeProbabilistic(...)` | `ProbabilisticAnalysis` |

Default app flow:

```ts
const ingredients = splitINCI(rawInci);
const assessment = analyzeINCI(ingredients, options);
const summary = summarizeAssessment(assessment, { rawIngredients: ingredients });
```

Scraped catalogue flow:

```ts
const clean = cleanInciString(rawScrapedInci);
const ingredients = splitINCI(clean);
const assessment = analyzeINCI(ingredients, options);
```

Do not call `canonicalizeINCI(...)` just to improve scoring. The analyzer
already resolves known aliases internally; canonicalization is for display,
storage, or downstream matching in your app.

## Quick Start

`AssessmentSummary` is the recommended response shape for product cards,
product detail pages, and backend APIs. Keep `ProductAssessment` for advanced
inspection and debugging.

```ts
import { analyzeINCI, splitINCI, summarizeAssessment } from "algo-derm";

const rawInci =
  "Aqua, Glycerin, Niacinamide, Alcohol Denat, Parfum, Limonene";
const ingredients = splitINCI(rawInci);

const assessment = analyzeINCI(ingredients, {
  profile: { sensitiveSkin: true },
  context: { leaveOn: true, formulaType: "serum", estimatedPH: 5.5 },
});

const summary = summarizeAssessment(assessment, {
  rawIngredients: ingredients,
  includeIngredientTags: true,
});

console.log(summary.rating);
console.log(summary.confidence);
console.log(summary.coverage.ratio);
console.log(summary.topRiskDrivers);
```

## Function Reference

Every export of the root `algo-derm` surface, grouped by purpose: signature,
expected input, returned output.

**Analysis — INCI → assessment**

| Function | Input | Output |
| --- | --- | --- |
| `analyzeINCI(inci, options?)` | `string \| string[]`, `AnalyzeOptions` | `ProductAssessment` — full per-axis payload (risks, benefits, contributors, interactions, coverage, regulatory notes). |
| `analyzeProbabilistic(inci, options?)` | `string \| string[]`, `AnalyzeOptions` | `ProbabilisticAnalysis` — calibrated global risk `[0,1]` + CI + contributors. Same input contract as `analyzeINCI`. |
| `summarizeAssessment(assessment, options?)` | `ProductAssessment`, `AssessmentSummaryOptions` | `AssessmentSummary` — compact rounded app shape. Options: `rawIngredients` (needed to derive tags), `includeIngredientTags`, `includeAllProductTags`, `productTags`. |

**Tags — assessment → badges**

| Function | Input | Output |
| --- | --- | --- |
| `tagProduct(assessment, rawIngredients)` | `ProductAssessment`, `string[]` | `ProductTag[]` — product badges, tri-state `present \| absent \| insufficient_data`. |
| `ingredientTags(assessment)` | `ProductAssessment` | `IngredientTag[]` — per-ingredient signals (`fragrance`, `fragrance_allergen`, `eu_restricted`…). |

**Parsing & cleaning — string → tokens / keys**

| Function | Input | Output |
| --- | --- | --- |
| `splitINCI(inci)` | `string` (clean comma list) | `string[]` — ordered tokens (order carries the concentration signal). |
| `stripPreamble(inci)` | `string` | `string` — input without a supported simple label/preamble (`Ingredients:`, `Composition:`, `INCI:`). `FORMULE INCI` is handled by `cleanInciString(...)`, `cleanInci(...)`, and the raw-string `analyzeINCI(...)` path. |
| `normalize(value)` | `string` (one token) | `string` — lowercase matching key (FR→EN transliteration, diacritics/punctuation stripped). |
| `canonicalizeINCI(labels)` | `string[]` | `string[]` — same length, each label → governed canonical INCI name; unknown passes through. Display/storage, not a prerequisite for scoring. |
| `cleanInciString(inci)` | `string` (scraped INCI) | `string` — repaired comma string (separators, labels, prose, legal). Display-preserving, idempotent. |
| `cleanInci(inci)` | `string` | `CleanInci` = `{ clean, ingredients, normalized, canonical }` — full pipeline in one call. |

**Claims & versioning**

| Function | Input | Output |
| --- | --- | --- |
| `buildKnownConcentrationsFromPackagingClaims(claims)` | `readonly PackagingConcentrationClaim[]` | `Record<string, number>` — `knownConcentrations` map (positive percentages only) for `context` or `options.packagingClaims`. |
| `TAG_DEFS_VERSION` | — (constant) | `number` — tag-definitions version; pin it consumer-side to detect a calibration change. |

`PackagingConcentrationClaim` needs at least one identifier (`ingredientSlug`,
`ingredientName`, or `inci`) plus a percentage: `concentrationPct` (preferred for
runtime payloads), or `concentrationValue` + `concentrationUnit` for corpus rows
(non-`%` units are ignored).

## analyzeProbabilistic

`analyzeProbabilistic(inci, options)` is the root-package wrapper for the
separate probabilistic scoring path. Use it when an application specifically
needs one global probability-like risk score with a confidence interval.

For ordinary app payloads, prefer `analyzeINCI(...)` plus
`summarizeAssessment(...)`: that path preserves per-axis risks, benefits,
drivers, product tags, ingredient tags, regulatory notes, coverage, and
declaration-only caveats.

```ts
import { analyzeProbabilistic, type ProbabilisticAnalysis } from "algo-derm";

const result: ProbabilisticAnalysis = analyzeProbabilistic(
  "Aqua, Glycerin, Retinol, Parfum",
  {
    profile: { sensitiveSkin: true },
    context: { leaveOn: true, formulaType: "serum" },
  },
);

console.log(result.globalRiskProbability); // ∈ [0, 1]
console.log(result.rating);               // "low" | "medium" | "high"
console.log(result.riskCI);               // { low, high }
console.log(result.contributors);         // per-ingredient probabilities
console.log(result.contraindicationsByProfile);
```

`ProbabilisticAnalysis` fields:

- `globalRiskProbability`: blended risk probability in `[0, 1]`.
- `riskCI`: confidence interval `{ low, high }` on the global probability.
- `rating`: `low | medium | high` derived from the same thresholds as `analyzeINCI`.
- `confidence` and `confidenceLabel`: overall estimate reliability.
- `contributors`: per-ingredient breakdown (`IngredientProbability[]`).
- `notes`: coverage and uncertainty notices.
- `contraindicationsByProfile`: per-profile risk tier (`low | medium | high`) for
  `sensitive_skin`, `rosacea`, `acne_prone`, and `pregnancy`.

Same input contract as `analyzeINCI`: accepts `string | string[]`, all
`AnalyzeOptions` fields (`profile`, `context`, `packagingClaims`,
`evidenceDatabase`, `scoringProfile`, `asOfDate`), and throws the same
`RangeError`/`TypeError` on invalid
inputs.

**Heuristic-only caveat:** ingredients matched only via heuristic patterns
(fragrance molecules without a curated DB entry, unrecognised essential oils…)
are not scored by this path. A product with no curated matches returns
`rating "low"` and a coverage note. Use `analyzeINCI` when per-axis
explainability or heuristic signal coverage is required.

There is no `summarizeAssessment` equivalent for `ProbabilisticAnalysis`;
consume the fields directly. The lower-level engine function is named
`analyzeINCIProbabilistic(...)` and belongs to the advanced `/engine` surface,
not the default app contract.

## Input Contract

`analyzeINCI(inci, options)` and `analyzeProbabilistic(inci, options)` share
the same input contract. Both accept:

- `inci: string`: a raw comma-separated INCI declaration.
- `inci: string[]`: an already split, ordered ingredient list.

Order matters because INCI position is used as a concentration signal. Preserve
the packaging order when possible.

Important options:

- `profile`: user skin context, such as `sensitiveSkin`, `acneProne`,
  `rosacea`, or `pregnant`.
- `context`: product usage context. `leaveOn` defaults to `true` when the
  context is omitted; pass `false` for rinse-off products. `formulaType` and
  `estimatedPH` help exposure, concentration, interaction, and tag gating.
- `packagingClaims`: structured concentration claims such as "5% niacinamide".
  Explicit `context.knownConcentrations` entries take precedence over packaging
  claims.
- `scoringProfile`: named algorithm policy (`mainstream`, `conservative`, or
  `permissive`). Omitted means `mainstream`. The two alternative names currently
  preserve mainstream values until each receives a separately justified
  calibration; see ADR-0015.
- `asOfDate`: inclusive regulatory reference date in `YYYY-MM-DD` form.
  Omitted means the latest modeled state: undated and open-ended rules apply,
  while closed windows do not. The engine never uses the wall clock.

Invalid input policy for both entry points:

- `inci` must be a non-empty raw string or a non-empty ordered array of
  non-empty strings. Blank strings, empty arrays, and blank array entries throw
  `RangeError`. Non-string runtime values throw `TypeError` for JavaScript
  callers.
- `context.estimatedPH`, when present, must be a finite number in `0..14`
  inclusive.
- `context.knownConcentrations` values must be finite percentage numbers in
  `0..100` inclusive. Percent `packagingClaims` values follow the same range;
  non-percent claim rows are ignored by claim ingestion.
- `context.formulaType`, when present, must be one of `serum`, `cream`, `gel`,
  `cleanser`, `gentle_cleanser`, `lotion`, or `sunscreen`.
- `scoringProfile`, when present, must be `mainstream`, `conservative`, or
  `permissive`.
- `asOfDate`, when present, must be a real calendar date in `YYYY-MM-DD` form.

### Cleaning Real-World INCI

`splitINCI` and `analyzeINCI` assume a well-formed comma list. Catalogue data
scraped from retailer pages rarely is: it carries broken separators (pipe,
middle-dot, en-dash, underscore, period), leading labels (`Ingrédients :`,
`Composition :`, `FORMULE INCI :`), mid-string prose-then-header blurbs,
marketing claim prefixes (`SANS PARABÈNES…`), trailing legal disclaimers, and
glued multi-word tokens. Run the cleaner first:

```ts
import { canonicalizeINCI, cleanInci, cleanInciString } from "algo-derm";

// String-level repair only (display-preserving — keeps casing and real names):
const clean = cleanInciString(rawScrapedInci);
const assessment = analyzeINCI(clean, options);

// Or the full pipeline in one call:
const { clean, ingredients, normalized, canonical } = cleanInci(rawScrapedInci);
//   clean       repaired comma string
//   ingredients ordered tokens (splitINCI of clean)
//   normalized  canonical lowercase matching keys (normalize of each token)
//   canonical   each token mapped to its governed canonical INCI name

// Or map an already-split list to governed canonical INCI names (display/storage):
const names = canonicalizeINCI(["Vitamin B3", "BHA"]); // ["Niacinamide", "Salicylic Acid"]
```

`canonicalizeINCI(labels)` resolves each label to its canonical INCI name from
the curated alias registry; unknown labels pass through unchanged so a list is
never silently shortened. It is display normalization, separate from the
engine's evidence matching — `analyzeINCI` already resolves aliases internally,
so canonicalizing first is for storage/display, not a prerequisite for scoring.

`cleanInciString` is best-effort and idempotent: an already-clean list passes
through unchanged, so it is safe to call unconditionally. It does not enforce a
guardrail — callers writing results back to storage should compare token counts
before committing. Skip it when the input is already a trusted comma list.

## Recommended Output: AssessmentSummary

Return `AssessmentSummary` from application APIs unless the consumer genuinely
needs the full engine payload.

The summary includes:

- `rating`: `low | medium | high`.
- `overallRisk`: rounded bounded score in `0..1`.
- `confidence` and `confidenceScore`.
- `coverage`: matched, heuristic-only, unmatched, total, and ratio.
- `risks` and `benefits`: rounded axis scores with frontend-friendly names.
- `topRiskDrivers` and `topBenefitDrivers`.
- `productTags`: product-level badges, present-only by default.
- `ingredientTags`: optional per-ingredient badges when requested.
- `regulatoryNotes`, `unmatchedIngredients`, `declarationOnlyRisk`, and
  `limitationNotes`.

> **Language policy:** `limitationNotes` is mixed-language. Engine-emitted
> notes are in English; the summary layer appends the declaration-only note in
> French (the app-facing locale). Consumers must not assume a single language
> across the array.

The summary intentionally omits heavy engine fields such as `contributors`,
`matchedEvidence`, `heuristicFlags`, `interactions`, `regulatoryFindings`, and the internal
ingredient resolution object.

## Advanced Output: ProductAssessment

`ProductAssessment` is the full structured analysis result. It is useful for
internal tools, debugging, audit screens, and richer partner integrations. It
contains per-axis risks, confidence factors, contributors, matched evidence,
heuristics, interactions, structured `regulatoryFindings`, compatibility
`regulatoryNotes`, and coverage details.

Each `RegulatoryFinding` records the matching `ruleId`, region, classified
status, inclusive effective window, evaluated reference date, `matchedIngredients`
(all matched labels) and `subjectIngredients` (the subset the finding legally
classifies — the basis for regulatory ingredient tags), concentration/use
modifiers plus a compact `detail` string, display note, source IDs, and whether
the source was curated or official. Findings report matching legal signals; they
are not a compliance certificate. See
[`algorithm/regulatory-engine.md`](algorithm/regulatory-engine.md).

Treat numeric scores as tolerance-oriented risk signals, not clinical
probabilities or efficacy estimates.

## Confidence, Coverage, And Declaration-Only Risk

`confidence` estimates how much support the engine has for the submitted INCI
list. It drops when many ingredients are unknown or heuristic-only.

`coverage.ratio` is the matched curated-evidence ratio over the submitted list.
Low coverage means the product may still have a score, but the result should be
shown with caution.

`declarationOnlyRisk` is an informational caveat for tail-declaration patterns.
It does not change `overallRisk` or `rating`, but applications should expose
it through `limitationNotes` or a nearby warning when present.

Recommended display caveats:

- Show a low-confidence caveat when `summary.confidence === "low"`.
- Show a low-coverage caveat when `summary.coverage.ratio < 0.6`.
- Show the declaration-only caveat when `summary.declarationOnlyRisk` is true.
- Keep regulatory notes informational; do not present them as a compliance
  certificate.

## Tags

Product tags from `tagProduct(...)` and `summarizeAssessment(...)` use a
tri-value state:

- `present`: the product qualifies for the tag under current evidence and
  context.
- `absent`: the product does not qualify.
- `insufficient_data`: coverage, confidence, or product context is not strong
  enough to support the positive claim.

`present` remains a back-compatible boolean equal to
`state === "present"`. Prefer `state` in new integrations.

Ingredient tags from `ingredientTags(...)` identify ingredient-level signals
such as fragrance, fragrance allergens, essential oils, and regulatory
restriction/prohibition notes. Regulatory tags project each finding's
`subjectIngredients`, so they cover both curated ingredients and ingredients
flagged only by the official lookup. They are useful for ingredient badges and
filters, but they are not standalone risk scores.

## Backend API Example

```ts
import { analyzeINCI, splitINCI, summarizeAssessment } from "algo-derm";

export const assessProductINCI = (rawInci: string) => {
  const ingredients = splitINCI(rawInci);
  const assessment = analyzeINCI(ingredients, {
    context: { leaveOn: true, formulaType: "cream" },
  });

  return summarizeAssessment(assessment, {
    rawIngredients: ingredients,
    includeIngredientTags: true,
  });
};
```

This keeps the public API payload compact while preserving caveats, tags, top
drivers, coverage, and regulatory notes.

## Limits To Keep Visible

The library does not provide:

- medical diagnosis;
- treatment advice;
- clinical efficacy prediction;
- guaranteed regulatory compliance;
- exact formula reconstruction;
- complete routine-level interaction modeling.

Use language such as "tolerance signal", "risk-oriented signal", "ingredient to
watch", and "coverage/confidence caveat". Avoid absolute marketing claims such as
"safe", "hypoallergenic", "non-irritating", "non-comedogenic", or "pregnancy
safe" unless the surrounding UI preserves the tag state and caveats.

## Package Contents And Budget

The runtime package is expected to include:

- `dist/` JavaScript and declaration files;
- `data/ingredients/ingredient_evidence.merged.json`;
- `data/inci/` runtime INCI alias registry;
- `data/rules/` runtime rules and normalization data;
- `data/regulatory/regulatory.lookup.json`;
- `data/regulatory/CELEX_02009R1223-20260501_FR_TXT.regulatory.json`;
- `README.md`, `LICENSE`, and this public contract.

Current budget for the packed package:

- compressed size: <= 800 KB;
- unpacked size: <= 6 MB.

`npm run test:package` enforces the package import contract and these package
content expectations from a locally installed tarball.
