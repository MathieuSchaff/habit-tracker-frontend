# data/rules/

Hand-edited rule data the engine loads at import via `require(...)`. These
files are rule sources, not ingredient sources. Ingredient aliases and common
names live in `data/inci/aliases/aliases.jsonl`.

## Files

| file | role | consumed by | git |
|---|---|---|---|
| `fr_normalization.json` | FR -> Latin/INCI token maps for generic language normalization | `src/parsing/normalize.ts` | tracked, published |
| `heuristic_rules.json` | pattern-based risk flags for ingredients absent from the curated DB | `src/engine/resolution/heuristics.ts` (+ `scripts/audit-coverage.ts`) | tracked, published |
| `interaction_rules.json` | multi-ingredient / context / profile risk adjustments | `src/engine/interactions.ts` | tracked, published |

## Schemas

### `fr_normalization.json` - three string-to-string maps applied by `normalize`

- `head` - botanical head noun (`huile` -> `oil`), used in positional `X de Y` patterns.
- `part` - plant part, singular + plural (`feuilles` -> `leaf`).
- `token` - whole-word substitutions for generic FR normalization.

Keys are pre-normalized (lowercase, accents stripped): `normalize` folds case +
accents before applying the maps. JSON key insertion order is significant.

### Ingredient aliases

Do not add ingredient-specific aliases here. Add them to the ingredient's
entry in `data/inci/aliases/aliases.jsonl`, the single governed source for canonical
INCI ↔ alias mappings (feeds both normalization and evidence matching).

### `heuristic_rules.json` - array; matcher in `resolution/heuristics.ts`

| field | meaning |
|---|---|
| `heuristic` | flag id (member of the `HeuristicFlag["heuristic"]` union) |
| `patterns` | substring list, OR - fires if the ingredient contains any |
| `groups` | `string[][]`, AND across groups, OR inside each |
| `axes` | risk axes the flag hints at |
| `riskHint` | `0..1` weight (downstream scaled by `HEURISTIC_DRIVER_SCALE`) |
| `note` | human rationale |

A rule uses `patterns` or `groups`, never both. A heuristic flag is not a
curated DB hit, so scoring scales it down and confidence reflects that.

### `interaction_rules.json` - array; evaluator in `interactions.ts`

Fires only when every gate passes; matched `adjustment`s are summed (signed:
negative = mitigation).

| field | meaning |
|---|---|
| `id` | rule id; prefixes the emitted note |
| `requires` | needle list, AND (all present) |
| `requiresAny` | needle list, OR (>=1); enforced only when non-empty |
| `requiresEach` | `string[][]`, AND-of-OR (each group needs one hit) |
| `contextCondition` | `leaveOn` exact and/or `estimatedPH` range; pH rules silent when pH unknown |
| `profileCondition` | profile flags matched exactly; silent when the flag is undefined |
| `axes` | risk axes adjusted |
| `adjustment` | signed delta added to risk |
| `evidenceLevel` | `A`-`D` provenance strength |
| `note` | human rationale |

Needle matching is alias-aware through the generated ingredient evidence DB.

## Editing

No regeneration step for rule files. After any edit run `npm run check:all`.
Edits to `heuristic_rules.json` / `interaction_rules.json` move product scoring,
so run `npm run benchmark:gold` before/after when the locked gold set matters.
